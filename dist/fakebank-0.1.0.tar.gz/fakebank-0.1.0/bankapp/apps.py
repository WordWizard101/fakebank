from django.apps import AppConfig


class BankappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bankapp'
   
    def ready(self):
        import bankapp.signals
