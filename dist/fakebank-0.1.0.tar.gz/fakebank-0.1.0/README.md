# Fake Bank App

A Django-based banking application for managing user accounts, transactions, and admin features.

## Overview
This project implements a fake banking system with user registration, login, account management, transactions (deposits, withdrawals, payments), admin dashboards, and password recovery. It uses PostgreSQL as the database, secured with root admin credentials (`username: root`, `password: pass1pass1`).

## Installation Instructions

### Prerequisites
- Python 3.13.x
- PostgreSQL (for database)
- Homebrew (optional, for macOS PostgreSQL installation)

### Steps

1. **Clone the Repository**
   - If you have a Git repository, clone it:
     ```bash
     git clone <your-repo-url>
